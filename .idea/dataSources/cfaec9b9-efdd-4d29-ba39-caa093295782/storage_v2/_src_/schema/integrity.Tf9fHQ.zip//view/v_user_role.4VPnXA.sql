create definer = root@localhost view v_user_role as
select `integrity`.`t_user`.`username`    AS `username`,
       `integrity`.`t_user`.`roleid`      AS `roleid`,
       `integrity`.`t_user`.`password`    AS `password`,
       `integrity`.`t_user`.`realname`    AS `realname`,
       `integrity`.`t_user`.`gender`      AS `gender`,
       `integrity`.`t_user`.`phone`       AS `phone`,
       `integrity`.`t_user`.`level`       AS `level`,
       `integrity`.`t_user`.`avatar`      AS `avatar`,
       `integrity`.`t_user`.`language`    AS `language`,
       `integrity`.`t_user`.`enabled`     AS `enabled`,
       `integrity`.`t_user`.`token`       AS `token`,
       `integrity`.`t_role`.`name`        AS `name`,
       `integrity`.`t_role`.`description` AS `description`
from (`integrity`.`t_role`
         join `integrity`.`t_user` on ((`integrity`.`t_user`.`roleid` = `integrity`.`t_role`.`id`)));

-- comment on column v_user_role.username not supported: 用户名

-- comment on column v_user_role.roleid not supported: 角色ID

-- comment on column v_user_role.password not supported: 密码

-- comment on column v_user_role.realname not supported: 真实姓名

-- comment on column v_user_role.gender not supported: 性别

-- comment on column v_user_role.phone not supported: 电话

-- comment on column v_user_role.level not supported: 资历水平

-- comment on column v_user_role.avatar not supported: 头像

-- comment on column v_user_role.language not supported: 语言

-- comment on column v_user_role.enabled not supported: 状态：1启用 0禁用

-- comment on column v_user_role.name not supported: 名称

-- comment on column v_user_role.description not supported: 描述

