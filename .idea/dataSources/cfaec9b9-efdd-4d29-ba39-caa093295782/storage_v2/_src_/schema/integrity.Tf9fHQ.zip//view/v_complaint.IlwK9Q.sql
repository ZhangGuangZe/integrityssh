create definer = root@localhost view v_complaint as
select `integrity`.`t_complaint`.`id`       AS `id`,
       `integrity`.`t_complaint`.`object`   AS `object`,
       `integrity`.`t_complaint`.`reason`   AS `reason`,
       `integrity`.`t_complaint`.`status`   AS `status`,
       `integrity`.`t_complaint`.`time`     AS `time`,
       `integrity`.`t_complaint`.`operator` AS `operator`,
       `integrity`.`t_complaint`.`result`   AS `result`,
       `integrity`.`t_complaint`.`username` AS `username`,
       `integrity`.`t_user`.`phone`         AS `phone`
from (`integrity`.`t_complaint`
         join `integrity`.`t_user` on ((`integrity`.`t_complaint`.`username` = `integrity`.`t_user`.`username`)));

-- comment on column v_complaint.id not supported: 投诉编号

-- comment on column v_complaint.object not supported: 投诉对象

-- comment on column v_complaint.reason not supported: 投诉原因

-- comment on column v_complaint.status not supported: 审核状态

-- comment on column v_complaint.time not supported: 投诉时间

-- comment on column v_complaint.operator not supported: 操作人员

-- comment on column v_complaint.result not supported: 投诉结果

-- comment on column v_complaint.username not supported: 用户名

-- comment on column v_complaint.phone not supported: 电话

