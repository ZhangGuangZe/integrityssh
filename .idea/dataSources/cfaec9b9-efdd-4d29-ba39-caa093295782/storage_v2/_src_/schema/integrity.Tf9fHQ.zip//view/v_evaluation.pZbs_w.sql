create definer = root@localhost view v_evaluation as
select `integrity`.`t_evaluation`.`id`       AS `id`,
       `integrity`.`t_evaluation`.`person`   AS `person`,
       `integrity`.`t_evaluation`.`content`  AS `content`,
       `integrity`.`t_evaluation`.`star`     AS `star`,
       `integrity`.`t_evaluation`.`time`     AS `time`,
       `integrity`.`t_evaluation`.`username` AS `username`
from (`integrity`.`t_evaluation`
         join `integrity`.`t_user` on ((`integrity`.`t_evaluation`.`username` = `integrity`.`t_user`.`username`)));

-- comment on column v_evaluation.id not supported: 评价编号

-- comment on column v_evaluation.person not supported: 评价对象

-- comment on column v_evaluation.content not supported: 评价内容

-- comment on column v_evaluation.star not supported: 评分

-- comment on column v_evaluation.time not supported: 评价时间

-- comment on column v_evaluation.username not supported: 用户名

